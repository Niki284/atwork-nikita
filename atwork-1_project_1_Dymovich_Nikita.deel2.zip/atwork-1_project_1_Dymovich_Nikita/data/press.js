const pressdate = [{
    
        foto : "",
        quli : "Arne Quinze builds Lupine Tower for Frieze Sculpture, Regent's Park",
        title : "Frieze — London",
        paragraph : "This year, Frieze Sculpture returns to The Regent’s Park from 5 – 18 October, featuring 12...",
        link: "https://www.arnequinze.com/press#:~:text=October%2C%20featuring%2012...-,Open%20press%20release,-The%20first%20permanent"
    },
    {
        foto : "",
        quli : "The first permanent public art sculpture by Arne Quinze in France",
        title : "The Beautiful Dreamer — Paris",
        paragrafe : "Arne Quinze continues his journey to reshape our cities into more human environments with this...",
        link: "https://www.arnequinze.com/press#:~:text=environments%20with%20this...-,Open%20press%20release,-Arne%20Quinze%20press"
    },
    {
        foto : "",
        quli : "Arne Quinze press release",
        title : "My secret Garden — Valencia",
        paragrafe : "“My Secret Garden Valencia” presents a series of six public sculptures that will enter into...",
        link: "#"
    },



    {
        foto : "",
        quli : "Frieze Sculpture Park opens its doors to nature",
        title : "Financial Times about Frieze Sculpture",
        paragrafe : "An upbeat free-to-wander exhibition combines playfulness with serious concerns of contemporary...",
        link: "https://www.arnequinze.com/press#:~:text=concerns%20of%20contemporary...-,download%20article,-Visit%20Arne%20Quinze%27s"
    },
    {
        foto : "",
        quli : "Visit Arne Quinze's Secret Garden until the 1st of March",
        title : "My Secret Garden, Valencia — Extended",
        paragrafe : "Since February 2019, the open-air exhibition of Arne Quinze already attracted 3 million visitors!...",
        link: "http://www.viuvalencia.com/articulo/exposicion_valencia_febrero_gratis/590621076?fbclid=IwAR0eyzjukTOF_kIhXwi1yFWtUrk8kxOFNR4VMiOPd-UOUPjSlgYz5nTucqU"
    },
    {
        foto : "",
        descripti : "An inspirational tour with Belgian most famous hip hop DJ",
        title : "DJ Lefto in our studio",
        paragrafe : "In this RTBF series, Hadja Lahbib follows Lefto visiting some of his friends artists and...",
        link: "https://www.rtbf.be/auvio/detail_tout-le-baz-art?id=2576946&jwsource=fb&fbclid=IwAR23CB0dqzjvcTZVy3R0x-x-kGrr2kpLmDeEbm9_u4G5DXQQAepjLF07YBA"
    },
    
    
]